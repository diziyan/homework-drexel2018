That's the result of the finding the time stamp of every version of linux kernel.
The following text file is about the data.
And I made a histogram.